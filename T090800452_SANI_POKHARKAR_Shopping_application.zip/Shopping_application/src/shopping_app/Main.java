package shopping_app;

import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static User user;
    private static ShoppingCart cart = new ShoppingCart();

    public static void main(String[] args) {
        System.out.println("Welcome to the Online Shopping App!");
        loginMenu();
    }

    private static void loginMenu() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        user = new User(username, password);
        mainMenu();
    }

    private static void mainMenu() {
        while (true) {
            System.out.println("\n1. View Products");
            System.out.println("2. View Cart");
            System.out.println("3. Checkout");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> viewProducts();
                case 2 -> viewCart();
                case 3 -> checkout();
                case 4 -> exitApp();
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }

    private static void viewProducts() {
        for (Product product : Product.getAllProducts()) {
            System.out.println(product);
        }
        System.out.print("Enter Product ID to add to cart, or 0 to go back: ");
        int productId = scanner.nextInt();
        scanner.nextLine();

        if (productId != 0) {
            Product product = Product.getProductById(productId);
            if (product != null) {
                cart.addProduct(product);
                System.out.println(product.getName() + " added to cart.");
            } else {
                System.out.println("Product not found.");
            }
        }
    }

    private static void viewCart() {
        cart.viewCart();
    }

    private static void checkout() {
        Order order = cart.checkout();
        if (order != null) {
            System.out.println("Order placed successfully!");
            System.out.println("Order Summary: " + order);
        } else {
            System.out.println("Cart is empty.");
        }
    }

    private static void exitApp() {
        System.out.println("Thank you for using the Online Shopping App!");
        System.exit(0);
    }

}
