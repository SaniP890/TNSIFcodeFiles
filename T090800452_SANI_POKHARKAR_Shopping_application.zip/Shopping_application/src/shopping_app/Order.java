package shopping_app;

import java.util.List;

public class Order {
    private static int orderCounter = 1;
    private int orderId;
    private List<Product> products;

    public Order(List<Product> products) {
        this.orderId = orderCounter++;
        this.products = products;
    }

    @Override
    public String toString() {
        double total = products.stream().mapToDouble(Product::getPrice).sum();
        return "Order ID: " + orderId + ", Total: $" + total;
    }

}
