package shopping_app;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Product> cartItems = new ArrayList<>();

    public void addProduct(Product product) {
        cartItems.add(product);
    }

    public void viewCart() {
        if (cartItems.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        System.out.println("Cart Items:");
        double total = 0;
        for (Product product : cartItems) {
            System.out.println(product);
            total += product.getPrice();
        }
        System.out.println("Total: $" + total);
    }

    public Order checkout() {
        if (cartItems.isEmpty()) {
            return null;
        }
        Order order = new Order(cartItems);
        cartItems.clear();
        return order;
    }
}
